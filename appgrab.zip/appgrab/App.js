import React, { useMemo, useRef, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  StatusBar,
  Modal,
  TextInput,
  Pressable,
  Alert,
  ActivityIndicator,
} from 'react-native';

const FILTERS = [
  'todos',
  'Desenvolvimento Web',
  'Suporte Técnico',
  'Design Gráfico / UI-UX',
  'Cloud & Infraestrutura',
  'Mobile',
  'Data Science / IA',
];

const INITIAL_SERVICOS = [
  {
    id: 1,
    titulo: 'Loja Virtual Completa',
    desc: 'Cliente busca desenvolvedor React para e-commerce com carrinho, pagamento e painel admin.',
    categoria: 'Desenvolvimento Web',
    valor: 3500,
    cidade: 'São Paulo - SP',
    urgencia: 'urgente',
    status: 'aberto',
    cliente: 'João Silva',
  },
  {
    id: 2,
    titulo: 'Notebook Superaquecendo',
    desc: 'Necessário suporte técnico urgente. Limpeza interna, pasta térmica e diagnóstico completo.',
    categoria: 'Suporte Técnico',
    valor: 250,
    cidade: 'Campinas - SP',
    urgencia: 'hoje',
    status: 'aberto',
    cliente: 'Maria Souza',
  },
  {
    id: 3,
    titulo: 'Identidade Visual para Startup',
    desc: 'Logo, paleta de cores, tipografia e templates para redes sociais. Briefing disponível.',
    categoria: 'Design Gráfico / UI-UX',
    valor: 1800,
    cidade: 'Remoto',
    urgencia: 'normal',
    status: 'aberto',
    cliente: 'Pedro Alves',
  },
  {
    id: 4,
    titulo: 'Migração para AWS',
    desc: 'Migrar aplicação Node.js + PostgreSQL para EC2 + RDS. Configurar load balancer e backups automáticos.',
    categoria: 'Cloud & Infraestrutura',
    valor: 4200,
    cidade: 'Remoto',
    urgencia: 'hoje',
    status: 'aberto',
    cliente: 'Ana Lima',
  },
  {
    id: 5,
    titulo: 'App Mobile de Delivery',
    desc: 'Aplicativo React Native para delivery local. Telas: cardápio, pedido, rastreio, pagamento.',
    categoria: 'Mobile',
    valor: 6500,
    cidade: 'Rio de Janeiro - RJ',
    urgencia: 'normal',
    status: 'aberto',
    cliente: 'Carlos Melo',
  },
  {
    id: 6,
    titulo: 'Dashboard de BI',
    desc: 'Power BI conectado ao banco MySQL da empresa. 5 relatórios definidos. Treinamento incluído.',
    categoria: 'Data Science / IA',
    valor: 2800,
    cidade: 'Belo Horizonte - MG',
    urgencia: 'urgente',
    status: 'aberto',
    cliente: 'Fernanda Cruz',
  },
  {
    id: 7,
    titulo: 'Sistema de Agendamento Online',
    desc: 'Sistema web para clínica médica agendar consultas, enviar lembretes por WhatsApp e gerenciar pacientes.',
    categoria: 'Desenvolvimento Web',
    valor: 5200,
    cidade: 'São Paulo - SP',
    urgencia: 'hoje',
    status: 'aberto',
    cliente: 'Dr. Roberto',
  },
  {
    id: 8,
    titulo: 'Configurar Servidor Linux',
    desc: 'Configurar VPS Ubuntu com Nginx, SSL, PHP e banco de dados para hospedar e-commerce.',
    categoria: 'Cloud & Infraestrutura',
    valor: 800,
    cidade: 'Remoto',
    urgencia: 'normal',
    status: 'aberto',
    cliente: 'Loja ABC',
  },
];

const TECNICOS = [
  {
    id: 1,
    nome: 'Will Frontarolli',
    role: 'Desenvolvedor Full Stack',
    skills: ['React', 'Node.js', 'UI/UX', 'TypeScript'],
    rating: '4.9',
    servicos: 124,
    foto: 'https://i.pravatar.cc/150?img=12',
    bio: 'Desenvolvedor full stack com 5 anos de experiência em plataformas modernas.',
    linkedin: 'linkedin.com/in/willfrontarolli',
    github: 'github.com/frontarolli-git',
  },
  {
    id: 2,
    nome: 'Gabriela de Oliveira',
    role: 'Designer UX/UI',
    skills: ['Figma', 'Branding', 'UX Research', 'Prototyping'],
    rating: '5.0',
    servicos: 210,
    foto: 'https://i.pravatar.cc/150?img=32',
    bio: 'Designer especializada em experiência do usuário com foco em produtos digitais e identidade de marca.',
    linkedin: 'linkedin.com/in/gabriela-oliveira',
    github: '',
  },
  {
    id: 3,
    nome: 'Gabriel Nobre',
    role: 'Cloud Engineer & DevOps',
    skills: ['AWS', 'Docker', 'Kubernetes', 'CI/CD'],
    rating: '4.8',
    servicos: 88,
    foto: 'https://i.pravatar.cc/150?img=54',
    bio: 'Especialista em infraestrutura como código, pipelines DevOps e otimização de custos.',
    linkedin: 'linkedin.com/in/gabrielnobre',
    github: 'github.com/gabrielnobre',
  },
  {
    id: 4,
    nome: 'Ana Karolina Kanzler',
    role: 'Data Scientist & IA',
    skills: ['Python', 'Machine Learning', 'Power BI', 'SQL'],
    rating: '4.9',
    servicos: 65,
    foto: 'https://i.pravatar.cc/150?img=47',
    bio: 'Cientista de dados com expertise em machine learning, análise preditiva e visualização de dados.',
    linkedin: 'linkedin.com/in/anakanzler',
    github: 'github.com/akanzler',
  },
];

const CATEGORIAS = [
  {
    cat: 'Suporte Técnico',
    palavras: ['notebook', 'pc', 'computador', 'lento', 'travando', 'windows', 'formatar', 'hardware', 'memoria', 'ssd'],
    titulo: 'Manutenção e suporte técnico',
    valor_min: 150,
    valor_max: 800,
    tempo: '1 a 3 dias',
    diagnostico: 'Foi identificado um possível problema de desempenho ou configuração.',
    perfil: 'Técnico de suporte especializado em manutenção de computadores.',
  },
  {
    cat: 'Desenvolvimento Web',
    palavras: ['site', 'sistema', 'api', 'html', 'css', 'javascript', 'react', 'node', 'wordpress', 'ecommerce'],
    titulo: 'Desenvolvimento de sistema web',
    valor_min: 1000,
    valor_max: 10000,
    tempo: '1 a 6 semanas',
    diagnostico: 'O projeto envolve desenvolvimento ou manutenção de aplicação web.',
    perfil: 'Desenvolvedor Full Stack com experiência em aplicações web.',
  },
  {
    cat: 'Design Gráfico / UI-UX',
    palavras: ['logo', 'identidade visual', 'design', 'figma', 'layout', 'banner', 'marca', 'ux', 'ui'],
    titulo: 'Criação de identidade visual',
    valor_min: 3000,
    valor_max: 15000,
    tempo: '2 a 10 dias',
    diagnostico: 'A solicitação está relacionada à criação ou melhoria visual de uma marca ou produto digital.',
    perfil: 'Designer gráfico especializado em branding e UI/UX.',
  },
  {
    cat: 'Cloud & Infraestrutura',
    palavras: ['servidor', 'aws', 'cloud', 'vps', 'linux', 'rede', 'infraestrutura', 'nginx', 'docker'],
    titulo: 'Infraestrutura e servidores',
    valor_min: 500,
    valor_max: 5000,
    tempo: '2 a 7 dias',
    diagnostico: 'O serviço envolve configuração ou manutenção de infraestrutura tecnológica.',
    perfil: 'Especialista em Cloud e Infraestrutura.',
  },
  {
    cat: 'Mobile',
    palavras: ['app', 'aplicativo', 'android', 'ios', 'celular', 'mobile', 'flutter', 'react native'],
    titulo: 'Desenvolvimento de aplicativo',
    valor_min: 3000,
    valor_max: 15000,
    tempo: '3 a 8 semanas',
    diagnostico: 'O projeto envolve desenvolvimento ou manutenção de aplicativo móvel.',
    perfil: 'Desenvolvedor Mobile com experiência em Android e iOS.',
  },
  {
    cat: 'Data Science / IA',
    palavras: ['dados', 'dashboard', 'power bi', 'excel', 'ia', 'chatbot', 'automação', 'python', 'sql'],
    titulo: 'Projeto de dados e automação',
    valor_min: 1000,
    valor_max: 7000,
    tempo: '1 a 4 semanas',
    diagnostico: 'A solicitação envolve análise de dados, automação ou inteligência artificial.',
    perfil: 'Especialista em dados e automação.',
  },
];

const getUrgenciaTag = (urgencia) => {
  if (urgencia === 'urgente') return { label: '🔴 Urgente', style: styles.tagUrgente };
  if (urgencia === 'hoje') return { label: '🟡 Esta semana', style: styles.tagHoje };
  return { label: '🟢 Tranquilo', style: styles.tagNormal };
};

export default function App() {
  const [screen, setScreen] = useState('home');
  const [modal, setModal] = useState(null);
  const [usuario, setUsuario] = useState(null);
  const [todosServicos, setTodosServicos] = useState(INITIAL_SERVICOS);
  const [meusServicos, setMeusServicos] = useState([]);
  const [servicosAndamento, setServicosAndamento] = useState([]);
  const [selectedPublicFilter, setSelectedPublicFilter] = useState('todos');
  const [selectedClientFilter, setSelectedClientFilter] = useState('todos');
  const [clientTab, setClientTab] = useState('feed');
  const [techTab, setTechTab] = useState('oportunidades');
  const [clientStep, setClientStep] = useState(1);
  const [techStep, setTechStep] = useState(1);
  const [iaLoading, setIaLoading] = useState(false);
  const [iaResult, setIaResult] = useState(null);
  const [formCliente, setFormCliente] = useState({
    nome: '',
    email: '',
    telefone: '',
    cidade: '',
    senha: '',
    confirma: '',
    problema: '',
  });
  const [formTecnico, setFormTecnico] = useState({
    nome: '',
    email: '',
    telefone: '',
    especialidade: '',
    bio: '',
    linkedin: '',
    github: '',
    senha: '',
    confirma: '',
  });
  const [formPublicar, setFormPublicar] = useState({
    titulo: '',
    categoria: '',
    desc: '',
    valor: '',
    urgencia: '',
    cidade: '',
  });
  const [serviceDetail, setServiceDetail] = useState(null);
  const [selectedTechProfile, setSelectedTechProfile] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('pix');
  const [sectionPositions, setSectionPositions] = useState({});
  const scrollRef = useRef(null);

  const filteredPublic = useMemo(() => {
    return selectedPublicFilter === 'todos'
      ? todosServicos
      : todosServicos.filter((item) => item.categoria === selectedPublicFilter);
  }, [selectedPublicFilter, todosServicos]);

  const filteredClientFeed = useMemo(() => {
    return selectedClientFilter === 'todos'
      ? todosServicos
      : todosServicos.filter((item) => item.categoria === selectedClientFilter);
  }, [selectedClientFilter, todosServicos]);

  const openModal = (name) => {
    setModal(name);
    if (name === 'cliente') {
      setClientStep(1);
      setIaResult(null);
      setIaLoading(false);
    }
    if (name === 'tecnico') {
      setTechStep(1);
    }
  };

  const closeModal = () => setModal(null);

  const goToSection = (key) => {
    setScreen('home');
    if (!scrollRef.current || sectionPositions[key] == null) return;
    setTimeout(() => {
      scrollRef.current.scrollTo({ y: sectionPositions[key], animated: true });
    }, 120);
  };

  const handleLogin = () => {
    if (!formCliente.email || !formCliente.senha) {
      Alert.alert('Aviso', 'Preencha email e senha.');
      return;
    }
    const user = {
      tipo: 'cliente',
      nome: 'Demo Cliente',
      email: formCliente.email,
      telefone: '(11) 91234-5678',
      cidade: 'São Paulo',
    };
    setUsuario(user);
    closeModal();
    setScreen('cliente');
    Alert.alert('Bem-vindo(a)', `Olá, ${user.nome}!`);
  };

  const handleClientNext = (step) => {
    if (step === 2) {
      if (!formCliente.nome || formCliente.nome.length < 2) {
        Alert.alert('Aviso', 'Digite um nome válido.');
        return;
      }
      if (!formCliente.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formCliente.email)) {
        Alert.alert('Aviso', 'Digite um email válido.');
        return;
      }
      if (!formCliente.telefone) {
        Alert.alert('Aviso', 'Digite um telefone.');
        return;
      }
    }
    if (step === 3) {
      if (!formCliente.senha || formCliente.senha.length < 6) {
        Alert.alert('Aviso', 'Senha mínima 6 caracteres.');
        return;
      }
      if (formCliente.senha !== formCliente.confirma) {
        Alert.alert('Aviso', 'Senhas não conferem.');
        return;
      }
    }
    setClientStep(step);
  };

  const analyzeWithIA = async () => {
    if (!formCliente.problema || formCliente.problema.length < 10) {
      Alert.alert('Aviso', 'Descreva o problema com pelo menos 10 caracteres.');
      return;
    }
    setIaLoading(true);
    setIaResult(null);
    await new Promise((resolve) => setTimeout(resolve, 1200));
    const texto = formCliente.problema.toLowerCase();
    let best = CATEGORIAS[0];
    let max = 0;
    CATEGORIAS.forEach((cat) => {
      const score = cat.palavras.reduce((acc, palavra) => acc + (texto.includes(palavra) ? 1 : 0), 0);
      if (score > max) {
        max = score;
        best = cat;
      }
    });
    let urgencia = 'normal';
    let urgenciaLabel = 'Sem pressa';
    if (texto.includes('urgente') || texto.includes('agora') || texto.includes('imediato')) {
      urgencia = 'urgente';
      urgenciaLabel = 'Atendimento imediato';
    } else if (texto.includes('hoje') || texto.includes('rápido') || texto.includes('essa semana')) {
      urgencia = 'hoje';
      urgenciaLabel = 'Prioridade média';
    }
    const result = {
      titulo: best.titulo,
      categoria: best.cat,
      urgencia,
      urgenciaLabel,
      valor_min: best.valor_min,
      valor_max: best.valor_max,
      diagnostico: best.diagnostico,
      perfil_tecnico: best.perfil,
      tempo_estimado: best.tempo,
    };
    setIaResult(result);
    setIaLoading(false);
  };

  const finalizeClient = () => {
    if (!formCliente.nome || !formCliente.email) {
      Alert.alert('Aviso', 'Complete o cadastro.');
      return;
    }
    const user = {
      tipo: 'cliente',
      nome: formCliente.nome,
      email: formCliente.email,
      telefone: formCliente.telefone,
      cidade: formCliente.cidade || '—',
    };
    setUsuario(user);
    setScreen('cliente');
    closeModal();
    if (formCliente.problema && iaResult) {
      const novoServico = {
        id: Date.now(),
        titulo: iaResult.titulo,
        desc: formCliente.problema,
        categoria: iaResult.categoria,
        valor: iaResult.valor_min,
        cidade: user.cidade,
        urgencia: iaResult.urgencia,
        status: 'aberto',
        cliente: user.nome,
      };
      setTodosServicos([novoServico, ...todosServicos]);
      setMeusServicos([novoServico, ...meusServicos]);
      Alert.alert('Sucesso', 'Serviço publicado com diagnóstico da IA! 🧠');
    } else if (formCliente.problema) {
      const novoServico = {
        id: Date.now(),
        titulo: 'Serviço sem categoria',
        desc: formCliente.problema,
        categoria: 'Suporte Técnico',
        valor: 0,
        cidade: user.cidade,
        urgencia: 'normal',
        status: 'aberto',
        cliente: user.nome,
      };
      setTodosServicos([novoServico, ...todosServicos]);
      setMeusServicos([novoServico, ...meusServicos]);
      Alert.alert('Sucesso', 'Serviço publicado!');
    } else {
      Alert.alert('Bem-vindo(a)', `Olá, ${user.nome}!`);
    }
  };

  const handleTechNext = (step) => {
    if (step === 2) {
      if (!formTecnico.nome || formTecnico.nome.length < 2) {
        Alert.alert('Aviso', 'Digite um nome válido.');
        return;
      }
      if (!formTecnico.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formTecnico.email)) {
        Alert.alert('Aviso', 'Digite um email válido.');
        return;
      }
      if (!formTecnico.especialidade) {
        Alert.alert('Aviso', 'Selecione sua especialidade.');
        return;
      }
    }
    setTechStep(step);
  };

  const finalizeTech = () => {
    if (!formTecnico.senha || formTecnico.senha.length < 6) {
      Alert.alert('Aviso', 'Senha mínima 6 caracteres.');
      return;
    }
    if (formTecnico.senha !== formTecnico.confirma) {
      Alert.alert('Aviso', 'Senhas não conferem.');
      return;
    }
    const user = {
      tipo: 'tecnico',
      nome: formTecnico.nome,
      email: formTecnico.email,
      telefone: formTecnico.telefone,
      especialidade: formTecnico.especialidade,
      bio: formTecnico.bio,
      linkedin: formTecnico.linkedin,
      github: formTecnico.github,
    };
    setUsuario(user);
    setScreen('tecnico');
    closeModal();
    Alert.alert('Bem-vindo(a)', `Olá, ${user.nome}!`);
  };

  const publishService = () => {
    if (!formPublicar.titulo || !formPublicar.categoria || !formPublicar.desc || !formPublicar.urgencia) {
      Alert.alert('Aviso', 'Preencha todos os campos obrigatórios.');
      return;
    }
    const novoServico = {
      id: Date.now(),
      titulo: formPublicar.titulo,
      desc: formPublicar.desc,
      categoria: formPublicar.categoria,
      valor: parseFloat(formPublicar.valor) || 0,
      cidade: formPublicar.cidade || 'Remoto',
      urgencia: formPublicar.urgencia,
      status: 'aberto',
      cliente: usuario?.nome || 'Anônimo',
    };
    setTodosServicos([novoServico, ...todosServicos]);
    setMeusServicos([novoServico, ...meusServicos]);
    closeModal();
    setFormPublicar({ titulo: '', categoria: '', desc: '', valor: '', urgencia: '', cidade: '' });
    Alert.alert('Sucesso', 'Serviço publicado com sucesso! 🐸');
  };

  const openServiceDetail = (item) => {
    setServiceDetail(item);
    openModal('detalheServiço');
  };

  const applyAsTechnician = (item) => {
    setServiceDetail(item);
    openModal('candidateService');
  };

  const confirmCandidate = () => {
    if (!serviceDetail) return;
    setServicosAndamento([serviceDetail, ...servicosAndamento]);
    setTodosServicos(
      todosServicos.map((item) =>
        item.id === serviceDetail.id ? { ...item, status: 'andamento' } : item
      )
    );
    closeModal();
    Alert.alert('Sucesso', 'Candidatura enviada! Aguarde confirmação. ⚡');
  };

  const completeService = (id) => {
    setServicosAndamento(servicosAndamento.filter((item) => item.id !== id));
    setTodosServicos(
      todosServicos.map((item) => (item.id === id ? { ...item, status: 'concluido' } : item))
    );
    Alert.alert('Sucesso', 'Serviço marcado como concluído! ✅');
  };

  const renderServiceCard = (item, tipo) => {
    const urg = getUrgenciaTag(item.urgencia);
    return (
      <View key={item.id} style={styles.serviceCard}>
        <Text style={[styles.tag, urg.style]}>{urg.label}</Text>
        <Text style={styles.serviceTitle}>{item.titulo}</Text>
        <Text style={styles.serviceDesc}>{item.desc}</Text>
        <View style={styles.serviceMeta}>
          <Text style={styles.metaText}>📍 {item.cidade}</Text>
          <Text style={styles.metaText}>📁 {item.categoria}</Text>
        </View>
        <Text style={styles.servicePrice}>
          {item.valor > 0 ? `R$ ${item.valor.toLocaleString('pt-BR')}` : 'A negociar'}
        </Text>
        <TouchableOpacity
          style={styles.btnPegar}
          onPress={() => (tipo === 'cliente' ? openServiceDetail(item) : applyAsTechnician(item))}
        >
          <Text style={styles.btnPegarText}>
            {tipo === 'cliente' ? 'Ver detalhes' : item.status === 'aberto' ? '🐸 Candidatar-se' : 'Serviço fechado'}
          </Text>
        </TouchableOpacity>
      </View>
    );
  };

  const renderTechCard = (tech) => (
    <View key={tech.id} style={styles.techCard}>
      <Image source={{ uri: tech.foto }} style={styles.techAvatar} />
      <Text style={styles.techName}>{tech.nome}</Text>
      <Text style={styles.techRole}>{tech.role}</Text>
      <View style={styles.skillsRow}>
        {tech.skills.map((skill) => (
          <Text key={skill} style={styles.skillTag}>
            {skill}
          </Text>
        ))}
      </View>
      <Text style={styles.techRating}>⭐ {tech.rating} · {tech.servicos} serviços</Text>
      <TouchableOpacity style={styles.btnVer} onPress={() => setSelectedTechProfile(tech)}>
        <Text style={styles.btnVerText}>Ver Perfil Completo</Text>
      </TouchableOpacity>
    </View>
  );

  const clientProfile = usuario && usuario.tipo === 'cliente';
  const techProfile = usuario && usuario.tipo === 'tecnico';

  const handleSectionLayout = (key) => (event) => {
    const layout = event?.nativeEvent?.layout;
    if (!layout) return;
    setSectionPositions((prev) => ({ ...prev, [key]: layout.y }));
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0047AB" />
      <View style={styles.header}>
        <TouchableOpacity style={styles.logoRow} onPress={() => setScreen('home')}>
          <Image
            source={{ uri: 'https://frontarolli-git.github.io/logoGRAB.jpeg' }}
            style={styles.logoImage}
          />
          <Text style={styles.logoText}>GRAB <Text style={styles.logoTextRed}>Tech</Text></Text>
        </TouchableOpacity>
        <View style={styles.headerActions}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <TouchableOpacity onPress={() => goToSection('funcionalidades')}>
              <Text style={styles.headerLink}>Funcionalidades</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => goToSection('servicos')}>
              <Text style={styles.headerLink}>Serviços</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => goToSection('feed')}>
              <Text style={styles.headerLink}>Feed</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => goToSection('tecnicos')}>
              <Text style={styles.headerLink}>Técnicos</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => goToSection('sobre')}>
              <Text style={styles.headerLink}>Sobre</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
        <View style={styles.headerButtons}>
          {usuario ? (
            <>
              <TouchableOpacity style={styles.avatarMini} onPress={() => setScreen(usuario.tipo === 'cliente' ? 'cliente' : 'tecnico')}>
                <Text style={styles.avatarMiniText}>{usuario.nome?.charAt(0)?.toUpperCase()}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.btnOutline} onPress={() => { setUsuario(null); setScreen('home'); Alert.alert('Saída', 'Você saiu da conta.'); }}>
                <Text style={styles.btnOutlineText}>Sair</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <TouchableOpacity style={styles.btnOutline} onPress={() => openModal('login')}>
                <Text style={styles.btnOutlineText}>Entrar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.btnPrimary} onPress={() => openModal('escolha')}>
                <Text style={styles.btnPrimaryText}>Cadastrar</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>

      {screen === 'home' && (
        <ScrollView
          ref={scrollRef}
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.hero}>
            <View style={styles.heroText}>
              <Text style={styles.heroTitle}>
                Pegue o profissional certo em <Text style={styles.heroTitleRed}>minutos.</Text>
              </Text>
              <Text style={styles.heroSubtitle}>
                Marketplace inteligente de serviços em TI. Conectamos clientes e técnicos qualificados com IA de triagem e feed em tempo real.
              </Text>
              <View style={styles.heroButtons}>
                <TouchableOpacity style={styles.heroButtonPrimary} onPress={() => openModal('escolha')}>
                  <Text style={styles.heroButtonText}>🐸 Publicar Serviço</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.heroButtonSecondary} onPress={() => goToSection('feed')}>
                  <Text style={styles.heroButtonSecondaryText}>Explorar Feed</Text>
                </TouchableOpacity>
              </View>
            </View>
            <View style={styles.heroVisual}>
              <Image
                source={{ uri: 'https://frontarolli-git.github.io/logoGRAB.jpeg' }}
                style={styles.heroImage}
              />
              <View style={styles.heroCardFloat}>
                <View style={styles.statCard}>
                  <Text style={styles.statIcon}>🛠️</Text>
                  <Text style={styles.statLabel}>Serviços ativos</Text>
                  <Text style={styles.statVal}>1.240</Text>
                </View>
                <View style={styles.statCard}>
                  <Text style={styles.statIcon}>👨‍💻</Text>
                  <Text style={styles.statLabel}>Técnicos</Text>
                  <Text style={styles.statVal}>530</Text>
                </View>
                <View style={styles.statCard}>
                  <Text style={styles.statIcon}>⭐</Text>
                  <Text style={styles.statLabel}>Avaliação</Text>
                  <Text style={styles.statVal}>4.9</Text>
                </View>
              </View>
            </View>
          </View>

          <View onLayout={handleSectionLayout('funcionalidades')} style={styles.section}>
            <Text style={styles.sectionTitle}>Funcionalidades</Text>
            <Text style={styles.sectionSubtitle}>Marketplace + Rede Social + IA + Serviços Tech</Text>
            <View style={styles.cardsGrid}>
              {[
                { icon: '🐸', title: 'Feed Inteligente', desc: 'Serviços em formato de feed moderno, com filtros por categoria, urgência e localização.' },
                { icon: '⚡', title: 'Match Profissional', desc: 'Técnicos demonstram interesse em serviços abertos. Clientes escolhem o melhor perfil.' },
                { icon: '🧠', title: 'IA de Triagem', desc: 'Diagnóstico prévio inteligente antes de publicar. Categoriza e prioriza automaticamente.' },
                { icon: '🔗', title: 'Perfil Integrado', desc: 'Conecte LinkedIn, GitHub e Instagram. Portfólio completo em um só lugar.' },
                { icon: '💳', title: 'Pagamento Seguro', desc: 'Pix, cartão ou boleto com liberação somente após conclusão do serviço.' },
                { icon: '⭐', title: 'Avaliações', desc: 'Sistema de reputação para clientes e técnicos. Transparência total.' },
              ].map((item) => (
                <View key={item.title} style={styles.featCard}>
                  <Text style={styles.featIcon}>{item.icon}</Text>
                  <Text style={styles.featCardTitle}>{item.title}</Text>
                  <Text style={styles.featCardText}>{item.desc}</Text>
                </View>
              ))}
            </View>
          </View>

          <View onLayout={handleSectionLayout('servicos')} style={[styles.section, styles.sectionAlt]}>
            <Text style={styles.sectionTitle}>Serviços Disponíveis</Text>
            <Text style={styles.sectionSubtitle}>Tudo em tecnologia em um só lugar.</Text>
            <View style={styles.cardsGrid}>
              {[
                { icon: '💻', title: 'Desenvolvimento Web', desc: 'Sites, APIs, sistemas e plataformas completas.' },
                { icon: '🛠️', title: 'Suporte Técnico', desc: 'Manutenção, upgrades e resolução de problemas.' },
                { icon: '🎨', title: 'Design Gráfico', desc: 'Identidade visual, UI/UX e social media.' },
                { icon: '☁️', title: 'Cloud & Infra', desc: 'Servidores, redes e arquitetura em nuvem.' },
              ].map((item) => (
                <View key={item.title} style={styles.featCard}>
                  <Text style={styles.featIcon}>{item.icon}</Text>
                  <Text style={styles.featCardTitle}>{item.title}</Text>
                  <Text style={styles.featCardText}>{item.desc}</Text>
                </View>
              ))}
            </View>
          </View>

          <View onLayout={handleSectionLayout('feed')} style={styles.section}>
            <Text style={styles.sectionTitle}>Feed de Serviços</Text>
            <Text style={styles.sectionSubtitle}>Explore solicitações abertas — cadastre-se para pegar um serviço.</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterRow}>
              {FILTERS.map((filter) => (
                <TouchableOpacity
                  key={filter}
                  style={[
                    styles.filterBtn,
                    selectedPublicFilter === filter && styles.filterBtnActive,
                  ]}
                  onPress={() => setSelectedPublicFilter(filter)}
                >
                  <Text
                    style={[
                      styles.filterText,
                      selectedPublicFilter === filter && styles.filterTextActive,
                    ]}
                  >
                    {filter === 'todos' ? 'Todos' : filter}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <View style={styles.feedGrid}>
              {filteredPublic.map((item) => renderServiceCard(item, 'publico'))}
            </View>
          </View>

          <View onLayout={handleSectionLayout('tecnicos')} style={styles.section}>
            <Text style={styles.sectionTitle}>Técnicos em Destaque</Text>
            <Text style={styles.sectionSubtitle}>Profissionais qualificados prontos para atender.</Text>
            <View style={styles.cardsGrid}>
              {TECNICOS.map(renderTechCard)}
            </View>
          </View>

          <View onLayout={handleSectionLayout('sobre')} style={[styles.section, styles.aboutSection]}>
            <Image
              source={{ uri: 'https://frontarolli-git.github.io/logoGRAB.jpeg' }}
              style={styles.aboutLogo}
            />
            <Text style={[styles.sectionTitle, styles.aboutTitle]}>Sobre a GRAB</Text>
            <Text style={styles.aboutText}>
              Plataforma desenvolvida pela LookTech para revolucionar a contratação de serviços em tecnologia no Brasil. Conectamos quem precisa com quem entrega — rápido, seguro e inteligente.
            </Text>
          </View>

          <View style={styles.footer}>
            <Image
              source={{ uri: 'https://frontarolli-git.github.io/logoGRAB.jpeg' }}
              style={styles.footerLogo}
            />
            <Text style={styles.footerTitle}>🐸 GRAB Technology</Text>
            <Text style={styles.footerText}>Plataforma desenvolvida pela LookTech © 2026</Text>
          </View>
        </ScrollView>
      )}

      {screen === 'cliente' && usuario && (
        <ScrollView contentContainerStyle={styles.profileContent}>
          <View style={styles.profileHero}>
            <View style={styles.profileAvatar}>
              <Text style={styles.profileAvatarText}>{usuario.nome?.charAt(0)?.toUpperCase()}</Text>
            </View>
            <Text style={styles.profileName}>{usuario.nome}</Text>
            <Text style={styles.profileSubtitle}>👤 Cliente · {usuario.cidade || '—'}</Text>
          </View>
          <View style={styles.profileBody}>
            <View style={styles.tabRow}>
              {[
                { key: 'feed', label: '🐸 Feed' },
                { key: 'meus', label: '📋 Meus Serviços' },
                { key: 'dados', label: '👤 Dados' },
              ].map((tab) => (
                <TouchableOpacity
                  key={tab.key}
                  style={[styles.ptab, clientTab === tab.key && styles.ptabActive]}
                  onPress={() => setClientTab(tab.key)}
                >
                  <Text style={[styles.ptabText, clientTab === tab.key && styles.ptabTextActive]}>
                    {tab.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {clientTab === 'feed' && (
              <>
                <View style={styles.clientFeedHeader}>
                  <Text style={styles.clientSectionTitle}>Feed de Serviços</Text>
                  <TouchableOpacity style={styles.btnRed} onPress={() => openModal('publicar')}>
                    <Text style={styles.btnRedText}>+ Publicar Serviço</Text>
                  </TouchableOpacity>
                </View>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterRow}>
                  {FILTERS.map((filter) => (
                    <TouchableOpacity
                      key={filter}
                      style={[
                        styles.filterBtn,
                        selectedClientFilter === filter && styles.filterBtnActive,
                      ]}
                      onPress={() => setSelectedClientFilter(filter)}
                    >
                      <Text
                        style={[
                          styles.filterText,
                          selectedClientFilter === filter && styles.filterTextActive,
                        ]}
                      >
                        {filter === 'todos' ? 'Todos' : filter}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                <View style={styles.feedGrid}>
                  {filteredClientFeed.map((item) => renderServiceCard(item, 'cliente'))}
                </View>
              </>
            )}

            {clientTab === 'meus' && (
              <View>
                <Text style={styles.clientSectionTitle}>Meus Serviços Publicados</Text>
                {meusServicos.length === 0 ? (
                  <Text style={styles.emptyText}>Nenhum serviço publicado ainda.</Text>
                ) : (
                  meusServicos.map((item) => (
                    <View key={item.id} style={styles.myServiceCard}>
                      <View>
                        <Text style={styles.myServiceTitle}>{item.titulo}</Text>
                        <Text style={styles.myServiceSubtitle}>{item.categoria} · {item.cidade}</Text>
                      </View>
                      <View style={styles.myServiceStatus}>
                        <Text style={[styles.statusBadge, item.status === 'andamento' ? styles.statusAndamento : item.status === 'concluido' ? styles.statusConcluido : styles.statusAberto]}>
                          {item.status === 'concluido' ? '✅ Concluído' : item.status === 'andamento' ? '⚡ Em andamento' : '📢 Aberto'}
                        </Text>
                        <Text style={styles.myServicePrice}>
                          {item.valor > 0 ? `R$ ${item.valor.toLocaleString('pt-BR')}` : 'A negociar'}
                        </Text>
                      </View>
                    </View>
                  ))
                )}
              </View>
            )}

            {clientTab === 'dados' && (
              <View>
                <View style={styles.infoCard}>
                  <Text style={styles.infoTitle}>Informações da Conta</Text>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>Nome</Text>
                    <Text style={styles.infoValue}>{usuario.nome}</Text>
                  </View>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>Email</Text>
                    <Text style={styles.infoValue}>{usuario.email}</Text>
                  </View>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>Telefone</Text>
                    <Text style={styles.infoValue}>{usuario.telefone}</Text>
                  </View>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>Tipo</Text>
                    <Text style={styles.infoValue}>Cliente</Text>
                  </View>
                </View>
                <TouchableOpacity style={styles.btnOutline} onPress={() => { setUsuario(null); setScreen('home'); Alert.alert('Saída', 'Você saiu da conta.'); }}>
                  <Text style={styles.btnOutlineText}>Sair da conta</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </ScrollView>
      )}

      {screen === 'tecnico' && usuario && (
        <ScrollView contentContainerStyle={styles.profileContent}>
          <View style={styles.profileHero}>
            <View style={styles.profileAvatar}>
              <Text style={styles.profileAvatarText}>{usuario.nome?.charAt(0)?.toUpperCase()}</Text>
            </View>
            <Text style={styles.profileName}>{usuario.nome}</Text>
            <Text style={styles.profileSubtitle}>🔧 Técnico · {usuario.especialidade || '—'}</Text>
          </View>
          <View style={styles.profileBody}>
            <View style={styles.tabRow}>
              {[
                { key: 'oportunidades', label: '⚡ Oportunidades' },
                { key: 'andamento', label: '📋 Em Andamento' },
                { key: 'dados', label: '👤 Perfil' },
              ].map((tab) => (
                <TouchableOpacity
                  key={tab.key}
                  style={[styles.ptab, techTab === tab.key && styles.ptabActive]}
                  onPress={() => setTechTab(tab.key)}
                >
                  <Text style={[styles.ptabText, techTab === tab.key && styles.ptabTextActive]}>
                    {tab.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {techTab === 'oportunidades' && (
              <View style={{ width: '100%' }}>
                <Text style={styles.clientSectionTitle}>Serviços Disponíveis</Text>
                <View style={styles.feedGrid}>
                  {todosServicos.filter((item) => item.status === 'aberto').map((item) => renderServiceCard(item, 'tecnico'))}
                </View>
              </View>
            )}

            {techTab === 'andamento' && (
              <View>
                <Text style={styles.clientSectionTitle}>Serviços em Andamento</Text>
                {servicosAndamento.length === 0 ? (
                  <Text style={styles.emptyText}>Nenhum serviço em andamento.</Text>
                ) : (
                  servicosAndamento.map((item) => (
                    <View key={item.id} style={styles.myServiceCard}>
                      <View>
                        <Text style={styles.myServiceTitle}>{item.titulo}</Text>
                        <Text style={styles.myServiceSubtitle}>{item.categoria} · {item.cidade}</Text>
                      </View>
                      <View style={styles.myServiceStatus}>
                        <Text style={[styles.statusBadge, styles.statusAndamento]}>⚡ Em andamento</Text>
                        <TouchableOpacity style={styles.btnPegarMini} onPress={() => completeService(item.id)}>
                          <Text style={styles.btnPegarText}>Marcar concluído</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  ))
                )}
              </View>
            )}

            {techTab === 'dados' && (
              <View>
                <View style={styles.infoCard}>
                  <Text style={styles.infoTitle}>Perfil Profissional</Text>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>Nome</Text>
                    <Text style={styles.infoValue}>{usuario.nome}</Text>
                  </View>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>Email</Text>
                    <Text style={styles.infoValue}>{usuario.email}</Text>
                  </View>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>Especialidade</Text>
                    <Text style={styles.infoValue}>{usuario.especialidade}</Text>
                  </View>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>LinkedIn</Text>
                    <Text style={styles.infoValue}>{usuario.linkedin || '—'}</Text>
                  </View>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>GitHub</Text>
                    <Text style={styles.infoValue}>{usuario.github || '—'}</Text>
                  </View>
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>Bio</Text>
                    <Text style={styles.infoValue}>{usuario.bio || '—'}</Text>
                  </View>
                </View>
                <TouchableOpacity style={styles.btnOutline} onPress={() => { setUsuario(null); setScreen('home'); Alert.alert('Saída', 'Você saiu da conta.'); }}>
                  <Text style={styles.btnOutlineText}>Sair da conta</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </ScrollView>
      )}

      <Modal visible={modal === 'escolha'} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBackdrop} onPress={closeModal} />
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Como deseja entrar?</Text>
            <TouchableOpacity style={styles.choiceCard} onPress={() => openModal('cliente')}>
              <Text style={styles.choiceIcon}>👤</Text>
              <View style={styles.choiceContent}>
                <Text style={styles.choiceTitle}>Sou Cliente</Text>
                <Text style={styles.choiceText}>Preciso contratar um profissional de TI</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.choiceCard} onPress={() => openModal('tecnico')}>
              <Text style={styles.choiceIcon}>🔧</Text>
              <View style={styles.choiceContent}>
                <Text style={styles.choiceTitle}>Sou Técnico</Text>
                <Text style={styles.choiceText}>Quero oferecer meus serviços de TI</Text>
              </View>
            </TouchableOpacity>
            <Text style={styles.orDivider}>já tem conta?</Text>
            <TouchableOpacity style={styles.btnOutline} onPress={() => openModal('login')}>
              <Text style={styles.btnOutlineText}>Fazer Login</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={modal === 'login'} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBackdrop} onPress={closeModal} />
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Entrar na GRAB</Text>
            <View style={styles.field}>
              <Text style={styles.fieldLabel}>Email</Text>
              <TextInput
                style={styles.fieldInput}
                keyboardType="email-address"
                autoCapitalize="none"
                value={formCliente.email}
                onChangeText={(value) => setFormCliente({ ...formCliente, email: value })}
                placeholder="seu@email.com"
              />
            </View>
            <View style={styles.field}>
              <Text style={styles.fieldLabel}>Senha</Text>
              <TextInput
                style={styles.fieldInput}
                secureTextEntry
                value={formCliente.senha}
                onChangeText={(value) => setFormCliente({ ...formCliente, senha: value })}
                placeholder="••••••••"
              />
            </View>
            <TouchableOpacity style={styles.btnFullBlue} onPress={handleLogin}>
              <Text style={styles.btnFullBlueText}>Entrar</Text>
            </TouchableOpacity>
            <Text style={styles.orDivider}>não tem conta?</Text>
            <TouchableOpacity style={styles.btnOutline} onPress={() => openModal('escolha')}>
              <Text style={styles.btnOutlineText}>Criar conta grátis</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={modal === 'cliente'} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBackdrop} onPress={closeModal} />
          <View style={styles.modalBox}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => openModal('escolha')}>
                <Text style={styles.modalBack}>←</Text>
              </TouchableOpacity>
              <Text style={styles.modalTitle}>Cadastro Cliente</Text>
              <TouchableOpacity onPress={closeModal}>
                <Text style={styles.modalBack}>✕</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.modalSteps}>
              {[1, 2, 3].map((step) => (
                <View
                  key={step}
                  style={[
                    styles.stepDot,
                    step < clientStep && styles.stepDone,
                    step === clientStep && styles.stepActive,
                  ]}
                />
              ))}
            </View>
            {clientStep === 1 && (
              <>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>Nome completo</Text>
                  <TextInput
                    style={styles.fieldInput}
                    value={formCliente.nome}
                    onChangeText={(value) => setFormCliente({ ...formCliente, nome: value })}
                    placeholder="Seu nome"
                  />
                </View>
                <View style={styles.fieldRow}>
                  <View style={[styles.field, { flex: 1 }]}>
                    <Text style={styles.fieldLabel}>Email</Text>
                    <TextInput
                      style={styles.fieldInput}
                      keyboardType="email-address"
                      autoCapitalize="none"
                      value={formCliente.email}
                      onChangeText={(value) => setFormCliente({ ...formCliente, email: value })}
                      placeholder="email@exemplo.com"
                    />
                  </View>
                  <View style={[styles.field, { flex: 1 }]}>
                    <Text style={styles.fieldLabel}>Telefone</Text>
                    <TextInput
                      style={styles.fieldInput}
                      value={formCliente.telefone}
                      onChangeText={(value) => setFormCliente({ ...formCliente, telefone: value })}
                      placeholder="(11) 91234-5678"
                    />
                  </View>
                </View>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>Cidade</Text>
                  <TextInput
                    style={styles.fieldInput}
                    value={formCliente.cidade}
                    onChangeText={(value) => setFormCliente({ ...formCliente, cidade: value })}
                    placeholder="Ex: São Paulo"
                  />
                </View>
                <TouchableOpacity style={styles.btnFullBlue} onPress={() => handleClientNext(2)}>
                  <Text style={styles.btnFullBlueText}>Continuar →</Text>
                </TouchableOpacity>
              </>
            )}
            {clientStep === 2 && (
              <>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>Senha</Text>
                  <TextInput
                    style={styles.fieldInput}
                    secureTextEntry
                    value={formCliente.senha}
                    onChangeText={(value) => setFormCliente({ ...formCliente, senha: value })}
                    placeholder="Min. 6 caracteres"
                  />
                </View>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>Confirmar senha</Text>
                  <TextInput
                    style={styles.fieldInput}
                    secureTextEntry
                    value={formCliente.confirma}
                    onChangeText={(value) => setFormCliente({ ...formCliente, confirma: value })}
                    placeholder="Repita a senha"
                  />
                </View>
                <TouchableOpacity style={styles.btnFullBlue} onPress={() => handleClientNext(3)}>
                  <Text style={styles.btnFullBlueText}>Continuar →</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.btnOutline} onPress={() => setClientStep(1)}>
                  <Text style={styles.btnOutlineText}>← Voltar</Text>
                </TouchableOpacity>
              </>
            )}
            {clientStep === 3 && (
              <>
                {!iaResult && (
                  <>
                    <View style={styles.iaCard}>
                      <Text style={styles.iaHeader}>🧠 Qual o seu problema?</Text>
                      <Text style={styles.iaText}>
                        Nossa IA analisa e encontra o profissional certo para você.
                      </Text>
                    </View>
                    <View style={styles.field}>
                      <Text style={styles.fieldLabel}>Descreva o problema com detalhes</Text>
                      <TextInput
                        style={[styles.fieldInput, styles.textarea]}
                        multiline
                        value={formCliente.problema}
                        onChangeText={(value) => setFormCliente({ ...formCliente, problema: value })}
                        placeholder="Ex: Meu notebook Dell está muito lento..."
                      />
                    </View>
                    <TouchableOpacity style={styles.btnFullBlue} onPress={analyzeWithIA}>
                      <Text style={styles.btnFullBlueText}>🧠 Analisar com IA →</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.btnOutline} onPress={() => setClientStep(2)}>
                      <Text style={styles.btnOutlineText}>← Voltar</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.btnOutline} onPress={finalizeClient}>
                      <Text style={styles.btnOutlineText}>Pular esta etapa</Text>
                    </TouchableOpacity>
                  </>
                )}
                {iaLoading && (
                  <View style={styles.loadingBox}>
                    <ActivityIndicator size="large" color="#0047AB" />
                    <Text style={styles.loadingText}>Analisando seu problema...</Text>
                  </View>
                )}
                {iaResult && (
                  <>
                    <View style={styles.iaResultCard}>
                      <Text style={styles.iaResultTitle}>🔎 {iaResult.titulo}</Text>
                      <Text style={styles.iaResultText}>{iaResult.diagnostico}</Text>
                      <Text style={styles.iaResultText}>Técnico ideal: {iaResult.perfil_tecnico}</Text>
                      <Text style={styles.iaResultText}>Tempo estimado: {iaResult.tempo_estimado}</Text>
                    </View>
                    <View style={styles.tagRow}>
                      <Text style={[styles.iaTag, styles.iaTagCat]}>📁 {iaResult.categoria}</Text>
                      <Text style={[styles.iaTag, styles.iaTagUrg]}>
                        {iaResult.urgencia === 'urgente' ? '🔴 Atendimento imediato' : iaResult.urgencia === 'hoje' ? '🟡 Prioridade média' : '🟢 Sem pressa'}
                      </Text>
                      <Text style={[styles.iaTag, styles.iaTagVal]}>
                        💰 R$ {iaResult.valor_min.toLocaleString('pt-BR')} – R$ {iaResult.valor_max.toLocaleString('pt-BR')}
                      </Text>
                    </View>
                    <TouchableOpacity style={styles.btnFullBlue} onPress={finalizeClient}>
                      <Text style={styles.btnFullBlueText}>🐸 Criar conta e publicar serviço</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.btnOutline} onPress={() => setIaResult(null)}>
                      <Text style={styles.btnOutlineText}>Refazer análise</Text>
                    </TouchableOpacity>
                  </>
                )}
              </>
            )}
          </View>
        </View>
      </Modal>

      <Modal visible={modal === 'tecnico'} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBackdrop} onPress={closeModal} />
          <View style={styles.modalBox}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => openModal('escolha')}>
                <Text style={styles.modalBack}>←</Text>
              </TouchableOpacity>
              <Text style={styles.modalTitle}>Cadastro Técnico</Text>
              <TouchableOpacity onPress={closeModal}>
                <Text style={styles.modalBack}>✕</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.modalSteps}>
              {[1, 2, 3].map((step) => (
                <View
                  key={step}
                  style={[
                    styles.stepDot,
                    step < techStep && styles.stepDone,
                    step === techStep && styles.stepActive,
                  ]}
                />
              ))}
            </View>
            {techStep === 1 && (
              <>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>Nome completo</Text>
                  <TextInput
                    style={styles.fieldInput}
                    value={formTecnico.nome}
                    onChangeText={(value) => setFormTecnico({ ...formTecnico, nome: value })}
                    placeholder="Seu nome"
                  />
                </View>
                <View style={styles.fieldRow}>
                  <View style={[styles.field, { flex: 1 }]}>
                    <Text style={styles.fieldLabel}>Email</Text>
                    <TextInput
                      style={styles.fieldInput}
                      keyboardType="email-address"
                      autoCapitalize="none"
                      value={formTecnico.email}
                      onChangeText={(value) => setFormTecnico({ ...formTecnico, email: value })}
                      placeholder="email@exemplo.com"
                    />
                  </View>
                  <View style={[styles.field, { flex: 1 }]}>
                    <Text style={styles.fieldLabel}>Telefone</Text>
                    <TextInput
                      style={styles.fieldInput}
                      value={formTecnico.telefone}
                      onChangeText={(value) => setFormTecnico({ ...formTecnico, telefone: value })}
                      placeholder="(11) 91234-5678"
                    />
                  </View>
                </View>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>Especialidade principal</Text>
                  <TextInput
                    style={styles.fieldInput}
                    value={formTecnico.especialidade}
                    onChangeText={(value) => setFormTecnico({ ...formTecnico, especialidade: value })}
                    placeholder="Ex: Desenvolvimento Web"
                  />
                </View>
                <TouchableOpacity style={styles.btnFullBlue} onPress={() => handleTechNext(2)}>
                  <Text style={styles.btnFullBlueText}>Continuar →</Text>
                </TouchableOpacity>
              </>
            )}
            {techStep === 2 && (
              <>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>Bio profissional</Text>
                  <TextInput
                    style={[styles.fieldInput, styles.textarea]}
                    multiline
                    value={formTecnico.bio}
                    onChangeText={(value) => setFormTecnico({ ...formTecnico, bio: value })}
                    placeholder="Fale sobre sua experiência..."
                  />
                </View>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>LinkedIn (opcional)</Text>
                  <TextInput
                    style={styles.fieldInput}
                    value={formTecnico.linkedin}
                    onChangeText={(value) => setFormTecnico({ ...formTecnico, linkedin: value })}
                    placeholder="linkedin.com/in/..."
                  />
                </View>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>GitHub (opcional)</Text>
                  <TextInput
                    style={styles.fieldInput}
                    value={formTecnico.github}
                    onChangeText={(value) => setFormTecnico({ ...formTecnico, github: value })}
                    placeholder="github.com/..."
                  />
                </View>
                <TouchableOpacity style={styles.btnFullBlue} onPress={() => handleTechNext(3)}>
                  <Text style={styles.btnFullBlueText}>Continuar →</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.btnOutline} onPress={() => setTechStep(1)}>
                  <Text style={styles.btnOutlineText}>← Voltar</Text>
                </TouchableOpacity>
              </>
            )}
            {techStep === 3 && (
              <>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>Senha</Text>
                  <TextInput
                    style={styles.fieldInput}
                    secureTextEntry
                    value={formTecnico.senha}
                    onChangeText={(value) => setFormTecnico({ ...formTecnico, senha: value })}
                    placeholder="Min. 6 caracteres"
                  />
                </View>
                <View style={styles.field}>
                  <Text style={styles.fieldLabel}>Confirmar senha</Text>
                  <TextInput
                    style={styles.fieldInput}
                    secureTextEntry
                    value={formTecnico.confirma}
                    onChangeText={(value) => setFormTecnico({ ...formTecnico, confirma: value })}
                    placeholder="Repita a senha"
                  />
                </View>
                <View style={styles.infoBox}>
                  <Text style={styles.infoBoxText}>
                    ✅ Seu perfil ficará visível no feed de técnicos após aprovação.
                  </Text>
                </View>
                <TouchableOpacity style={styles.btnFullBlue} onPress={finalizeTech}>
                  <Text style={styles.btnFullBlueText}>🐸 Criar perfil técnico</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.btnOutline} onPress={() => setTechStep(2)}>
                  <Text style={styles.btnOutlineText}>← Voltar</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>

      <Modal visible={modal === 'publicar'} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBackdrop} onPress={closeModal} />
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Publicar Serviço</Text>
            <View style={styles.field}>
              <Text style={styles.fieldLabel}>Título do serviço</Text>
              <TextInput
                style={styles.fieldInput}
                value={formPublicar.titulo}
                onChangeText={(value) => setFormPublicar({ ...formPublicar, titulo: value })}
                placeholder="Ex: Loja virtual React + Node"
              />
            </View>
            <View style={styles.field}>
              <Text style={styles.fieldLabel}>Categoria</Text>
              <TextInput
                style={styles.fieldInput}
                value={formPublicar.categoria}
                onChangeText={(value) => setFormPublicar({ ...formPublicar, categoria: value })}
                placeholder="Ex: Desenvolvimento Web"
              />
            </View>
            <View style={styles.field}>
              <Text style={styles.fieldLabel}>Descrição detalhada</Text>
              <TextInput
                style={[styles.fieldInput, styles.textarea]}
                multiline
                value={formPublicar.desc}
                onChangeText={(value) => setFormPublicar({ ...formPublicar, desc: value })}
                placeholder="Descreva o que precisa ser feito..."
              />
            </View>
            <View style={styles.fieldRow}>
              <View style={[styles.field, { flex: 1 }]}>
                <Text style={styles.fieldLabel}>Orçamento (R$)</Text>
                <TextInput
                  style={styles.fieldInput}
                  keyboardType="numeric"
                  value={formPublicar.valor}
                  onChangeText={(value) => setFormPublicar({ ...formPublicar, valor: value })}
                  placeholder="0,00"
                />
              </View>
              <View style={[styles.field, { flex: 1 }]}>
                <Text style={styles.fieldLabel}>Urgência</Text>
                <TextInput
                  style={styles.fieldInput}
                  value={formPublicar.urgencia}
                  onChangeText={(value) => setFormPublicar({ ...formPublicar, urgencia: value })}
                  placeholder="urgente / hoje / normal"
                />
              </View>
            </View>
            <View style={styles.field}>
              <Text style={styles.fieldLabel}>Cidade / Local</Text>
              <TextInput
                style={styles.fieldInput}
                value={formPublicar.cidade}
                onChangeText={(value) => setFormPublicar({ ...formPublicar, cidade: value })}
                placeholder="Ex: São Paulo - SP"
              />
            </View>
            <TouchableOpacity style={styles.btnFullRed} onPress={publishService}>
              <Text style={styles.btnFullRedText}>🐸 Publicar Serviço</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={modal === 'detalheServiço'} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBackdrop} onPress={closeModal} />
          <View style={[styles.modalBox, { maxWidth: 520 }]}>
            <View style={styles.modalHeader}>
              <View />
              <Text style={styles.modalTitle}>{serviceDetail?.titulo}</Text>
              <TouchableOpacity onPress={closeModal}>
                <Text style={styles.modalBack}>✕</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.infoCard}>
              <Text style={styles.infoTitle}>{serviceDetail?.titulo}</Text>
              <Text style={styles.infoValue}>{serviceDetail?.desc}</Text>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Categoria</Text>
                <Text style={styles.infoValue}>{serviceDetail?.categoria}</Text>
              </View>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Local</Text>
                <Text style={styles.infoValue}>{serviceDetail?.cidade}</Text>
              </View>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Orçamento</Text>
                <Text style={styles.infoValue}>
                  {serviceDetail?.valor > 0 ? `R$ ${serviceDetail.valor.toLocaleString('pt-BR')}` : 'A negociar'}
                </Text>
              </View>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Publicado por</Text>
                <Text style={styles.infoValue}>{serviceDetail?.cliente}</Text>
              </View>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={modal === 'candidateService'} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBackdrop} onPress={closeModal} />
          <View style={styles.modalBox}>
            <View style={styles.modalHeader}>
              <View />
              <Text style={styles.modalTitle}>Candidatar-se ao Serviço</Text>
              <TouchableOpacity onPress={closeModal}>
                <Text style={styles.modalBack}>✕</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.serviceDetailTitle}>{serviceDetail?.titulo}</Text>
            <Text style={styles.serviceDetailDesc}>{serviceDetail?.desc}</Text>
            <View style={styles.field}>
              <Text style={styles.fieldLabel}>Valor que cobrarei (R$)</Text>
              <TextInput style={styles.fieldInput} keyboardType="numeric" />
            </View>
            <View style={styles.field}>
              <Text style={styles.fieldLabel}>Prazo estimado</Text>
              <TextInput style={styles.fieldInput} placeholder="Ex: 2-3 dias" />
            </View>
            <View style={styles.field}>
              <Text style={styles.fieldLabel}>Mensagem ao cliente</Text>
              <TextInput style={[styles.fieldInput, styles.textarea]} multiline />
            </View>
            <TouchableOpacity style={styles.btnFullBlue} onPress={confirmCandidate}>
              <Text style={styles.btnFullBlueText}>🐸 Enviar candidatura</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={!!selectedTechProfile} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBackdrop} onPress={() => setSelectedTechProfile(null)} />
          <View style={[styles.modalBox, { maxWidth: 480 }]}>
            <View style={styles.modalHeader}>
              <View />
              <Text style={styles.modalTitle}>Perfil do Técnico</Text>
              <TouchableOpacity onPress={() => setSelectedTechProfile(null)}>
                <Text style={styles.modalBack}>✕</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.techProfileHero}>
              <Image
                source={{ uri: selectedTechProfile?.foto }}
                style={styles.techProfileAvatar}
              />
              <Text style={styles.techProfileName}>{selectedTechProfile?.nome}</Text>
              <Text style={styles.techProfileRole}>{selectedTechProfile?.role}</Text>
              <View style={styles.tecStatRow}>
                <View style={styles.tecStat}>
                  <Text style={styles.tecStatVal}>⭐ {selectedTechProfile?.rating}</Text>
                  <Text style={styles.tecStatLbl}>Avaliação</Text>
                </View>
                <View style={styles.tecStat}>
                  <Text style={styles.tecStatVal}>{selectedTechProfile?.servicos}+</Text>
                  <Text style={styles.tecStatLbl}>Serviços</Text>
                </View>
                <View style={styles.tecStat}>
                  <Text style={styles.tecStatVal}>⚡</Text>
                  <Text style={styles.tecStatLbl}>Resposta rápida</Text>
                </View>
              </View>
            </View>
            <View style={styles.skillRowWrap}>
              {selectedTechProfile?.skills.map((skill) => (
                <Text key={skill} style={styles.skillTagSmall}>
                  {skill}
                </Text>
              ))}
            </View>
            <View style={styles.infoCard}>
              <Text style={styles.infoTitle}>Sobre</Text>
              <Text style={styles.infoValue}>{selectedTechProfile?.bio}</Text>
            </View>
            <View style={styles.infoCard}>
              <Text style={styles.infoTitle}>Links</Text>
              {selectedTechProfile?.linkedin ? (
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>🔗 LinkedIn</Text>
                  <Text style={[styles.infoValue, styles.linkText]}>{selectedTechProfile.linkedin}</Text>
                </View>
              ) : null}
              {selectedTechProfile?.github ? (
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>💻 GitHub</Text>
                  <Text style={[styles.infoValue, styles.linkText]}>{selectedTechProfile.github}</Text>
                </View>
              ) : null}
            </View>
            <TouchableOpacity style={styles.btnFullBlue} onPress={() => setSelectedTechProfile(null)}>
              <Text style={styles.btnFullBlueText}>Fechar perfil</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f4f7fb' },
  header: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    padding: 12,
    paddingTop: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    elevation: 12,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 12,
    zIndex: 20,
  },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logoImage: { width: 36, height: 36, borderRadius: 10, marginRight: 8 },
  logoText: { fontSize: 18, fontWeight: '800', color: '#0047AB' },
  logoTextRed: { color: '#ff355e' },
  headerActions: { flex: 1, marginLeft: 8 },
  headerLink: {
    color: '#0f172a',
    fontWeight: '600',
    marginRight: 16,
    fontSize: 13,
  },
  headerButtons: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  btnOutline: {
    borderWidth: 1.5,
    borderColor: '#0047AB',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 8,
  },
  btnOutlineText: { color: '#0047AB', fontWeight: '700' },
  btnPrimary: {
    backgroundColor: '#0047AB',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  btnPrimaryText: { color: '#fff', fontWeight: '700' },
  avatarMini: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#0047AB',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  avatarMiniText: { color: '#fff', fontWeight: '800' },
  content: { paddingBottom: 100 },
  hero: {
    backgroundColor: '#0047AB',
    padding: 20,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
  },
  heroText: { maxWidth: 560 },
  heroTitle: { color: '#fff', fontSize: 30, fontWeight: '800', marginBottom: 14 },
  heroTitleRed: { color: '#ff355e' },
  heroSubtitle: { color: '#c7d9f5', fontSize: 16, lineHeight: 24, marginBottom: 18 },
  heroButtons: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  heroButtonPrimary: {
    backgroundColor: '#ff355e',
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 18,
  },
  heroButtonText: { color: '#fff', fontWeight: '800' },
  heroButtonSecondary: {
    borderColor: 'rgba(255,255,255,0.6)',
    borderWidth: 1.4,
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 18,
  },
  heroButtonSecondaryText: { color: '#fff', fontWeight: '700' },
  heroVisual: { marginTop: 24, alignItems: 'center' },
  heroImage: {
    width: 200,
    height: 200,
    borderRadius: 28,
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.15)',
    marginBottom: 18,
  },
  heroCardFloat: {
    backgroundColor: 'rgba(255,255,255,0.12)',
    padding: 16,
    borderRadius: 20,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statCard: { alignItems: 'center' },
  statIcon: { fontSize: 20, marginBottom: 6 },
  statLabel: { fontSize: 11, color: '#c7d9f5' },
  statVal: { fontSize: 18, fontWeight: '800', color: '#fff' },
  section: { paddingHorizontal: 18, paddingVertical: 26 },
  sectionAlt: { backgroundColor: '#f8fbff' },
  sectionTitle: { fontSize: 26, fontWeight: '800', color: '#0047AB', marginBottom: 8 },
  sectionSubtitle: { fontSize: 15, color: '#64748b', marginBottom: 18 },
  cardsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12 },
  featCard: {
    width: '48%',
    backgroundColor: 'rgba(255,255,255,0.94)',
    borderRadius: 20,
    padding: 18,
    marginBottom: 12,
    shadowColor: '#0047AB',
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 4,
  },
  featIcon: { fontSize: 32, marginBottom: 10 },
  featCardTitle: { fontWeight: '700', fontSize: 15, color: '#0047AB', marginBottom: 8 },
  featCardText: { fontSize: 13, color: '#64748b', lineHeight: 20 },
  filterRow: { marginVertical: 12, flexDirection: 'row', gap: 10 },
  filterBtn: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    backgroundColor: '#fff',
    marginRight: 10,
  },
  filterBtnActive: {
    borderColor: '#0047AB',
    backgroundColor: '#eff6ff',
  },
  filterText: { fontSize: 12, color: '#64748b' },
  filterTextActive: { color: '#0047AB', fontWeight: '700' },
  feedGrid: { gap: 14, flexDirection: 'column' },
  serviceCard: {
    backgroundColor: '#fff',
    borderRadius: 18,
    padding: 18,
    marginBottom: 14,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 2,
  },
  tag: {
    alignSelf: 'flex-start',
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 20,
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 8,
  },
  tagUrgente: { backgroundColor: '#fff0f3', color: '#ff355e' },
  tagHoje: { backgroundColor: '#eff6ff', color: '#0047AB' },
  tagNormal: { backgroundColor: '#f0fdf4', color: '#16a34a' },
  serviceTitle: { fontSize: 16, fontWeight: '700', color: '#0f172a', marginBottom: 8 },
  serviceDesc: { color: '#64748b', fontSize: 13, lineHeight: 20, marginBottom: 14 },
  serviceMeta: { flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  metaText: { fontSize: 12, color: '#64748b' },
  servicePrice: { fontSize: 18, fontWeight: '800', color: '#0047AB' },
  btnPegar: {
    backgroundColor: '#0047AB',
    borderRadius: 12,
    paddingVertical: 12,
    marginTop: 10,
  },
  btnPegarMini: {
    backgroundColor: '#0047AB',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  btnPegarText: { color: '#fff', fontWeight: '700', textAlign: 'center' },
  techCard: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 2,
  },
  techAvatar: { width: 80, height: 80, borderRadius: 40, alignSelf: 'center', marginBottom: 12 },
  techName: { fontWeight: '700', fontSize: 15, color: '#0f172a', textAlign: 'center', marginBottom: 4 },
  techRole: { color: '#64748b', fontSize: 12, textAlign: 'center', marginBottom: 10 },
  skillsRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 6, marginBottom: 10 },
  skillTag: { backgroundColor: '#eff6ff', color: '#0047AB', paddingVertical: 4, paddingHorizontal: 9, borderRadius: 18, fontSize: 11 },
  skillTagSmall: { backgroundColor: '#eff6ff', color: '#0047AB', paddingVertical: 6, paddingHorizontal: 10, borderRadius: 18, fontSize: 12, marginRight: 8, marginBottom: 8 },
  techRating: { fontSize: 12, color: '#64748b', marginBottom: 10, textAlign: 'center' },
  btnVer: { borderWidth: 1, borderColor: '#0047AB', borderRadius: 12, paddingVertical: 10 },
  btnVerText: { color: '#0047AB', fontWeight: '700', textAlign: 'center' },
  aboutSection: { backgroundColor: '#001b3d', borderRadius: 24, paddingVertical: 30, alignItems: 'center' },
  aboutLogo: { width: 72, height: 72, borderRadius: 16, marginBottom: 18, borderWidth: 2, borderColor: 'rgba(255,255,255,0.2)' },
  aboutTitle: { color: '#fff' },
  aboutText: { color: '#c7d9f5', fontSize: 15, lineHeight: 24, maxWidth: 560, textAlign: 'center' },
  footer: { alignItems: 'center', paddingVertical: 28 },
  footerLogo: { width: 48, height: 48, borderRadius: 12, marginBottom: 12, opacity: 0.9 },
  footerTitle: { fontSize: 20, fontWeight: '800', color: '#0f172a', marginBottom: 6 },
  footerText: { color: '#94a3b8', fontSize: 13 },
  profileContent: { padding: 18, paddingBottom: 50 },
  profileHero: { backgroundColor: '#0047AB', borderRadius: 24, padding: 26, alignItems: 'center', marginBottom: 18 },
  profileAvatar: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: '#ff355e',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
  },
  profileAvatarText: { color: '#fff', fontSize: 34, fontWeight: '800' },
  profileName: { fontSize: 26, fontWeight: '800', color: '#fff', marginBottom: 6 },
  profileSubtitle: { color: '#c7d9f5', fontSize: 14 },
  profileBody: { marginTop: -24 },
  tabRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 20 },
  ptab: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    backgroundColor: '#fff',
  },
  ptabActive: { backgroundColor: '#0047AB', borderColor: '#0047AB' },
  ptabText: { color: '#64748b', fontSize: 13, fontWeight: '600' },
  ptabTextActive: { color: '#fff' },
  clientFeedHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10, marginBottom: 14 },
  clientSectionTitle: { fontSize: 20, fontWeight: '800', color: '#0f172a' },
  btnRed: { backgroundColor: '#ff355e', borderRadius: 12, paddingVertical: 12, paddingHorizontal: 14 },
  btnRedText: { color: '#fff', fontWeight: '700' },
  emptyText: { color: '#64748b', fontSize: 14 },
  infoCard: {
    backgroundColor: '#fff',
    borderRadius: 18,
    padding: 18,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  infoTitle: { fontSize: 15, fontWeight: '700', color: '#0f172a', marginBottom: 10 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
  infoLabel: { color: '#64748b', fontSize: 13 },
  infoValue: { fontWeight: '600', color: '#0f172a', fontSize: 13, maxWidth: '60%', textAlign: 'right' },
  statusBadge: { paddingVertical: 4, paddingHorizontal: 10, borderRadius: 20, fontSize: 11, fontWeight: '700' },
  statusAberto: { backgroundColor: '#fff7ed', color: '#ea580c' },
  statusAndamento: { backgroundColor: '#eff6ff', color: '#0047AB' },
  statusConcluido: { backgroundColor: '#f0fdf4', color: '#16a34a' },
  myServiceCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  myServiceTitle: { fontSize: 14, fontWeight: '700', color: '#0f172a', marginBottom: 4 },
  myServiceSubtitle: { fontSize: 12, color: '#64748b' },
  myServiceStatus: { alignItems: 'flex-end', marginTop: 10 },
  myServicePrice: { fontSize: 16, fontWeight: '800', color: '#0047AB', marginTop: 4 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalBackdrop: { ...StyleSheet.absoluteFillObject },
  modalBox: {
    width: '92%',
    maxWidth: 520,
    backgroundColor: '#fff',
    borderRadius: 24,
    padding: 22,
    zIndex: 2,
  },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 },
  modalTitle: { fontSize: 20, fontWeight: '800', color: '#0f172a' },
  modalBack: { fontSize: 22, color: '#64748b' },
  choiceCard: { flexDirection: 'row', alignItems: 'center', gap: 14, borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 18, padding: 16, marginBottom: 12 },
  choiceIcon: { fontSize: 28 },
  choiceContent: { flex: 1 },
  choiceTitle: { fontWeight: '700', fontSize: 15, marginBottom: 4 },
  choiceText: { fontSize: 13, color: '#64748b' },
  orDivider: { textAlign: 'center', color: '#64748b', marginVertical: 14, fontSize: 12 },
  field: { marginBottom: 14 },
  fieldLabel: { color: '#0f172a', fontSize: 13, fontWeight: '700', marginBottom: 6 },
  fieldInput: {
    backgroundColor: '#f8fbff',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    padding: 12,
    color: '#0f172a',
    fontSize: 14,
  },
  textarea: { minHeight: 90, textAlignVertical: 'top' },
  fieldRow: { flexDirection: 'row', gap: 10 },
  btnFullBlue: {
    backgroundColor: '#0047AB',
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 6,
  },
  btnFullBlueText: { color: '#fff', fontWeight: '700' },
  btnFullRed: {
    backgroundColor: '#ff355e',
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 6,
  },
  btnFullRedText: { color: '#fff', fontWeight: '700' },
  modalSteps: { flexDirection: 'row', gap: 6, marginBottom: 18 },
  stepDot: { flex: 1, height: 4, borderRadius: 4, backgroundColor: '#e2e8f0' },
  stepDone: { backgroundColor: '#0047AB' },
  stepActive: { backgroundColor: '#ff355e' },
  iaCard: { alignItems: 'center', marginBottom: 14 },
  iaHeader: { fontSize: 17, fontWeight: '800', marginBottom: 8, textAlign: 'center' },
  iaText: { color: '#64748b', fontSize: 13, textAlign: 'center', lineHeight: 20 },
  loadingBox: { alignItems: 'center', paddingVertical: 24 },
  loadingText: { color: '#64748b', marginTop: 14 },
  iaResultCard: { backgroundColor: '#eff6ff', borderRadius: 16, padding: 16, marginBottom: 14 },
  iaResultTitle: { fontSize: 15, fontWeight: '800', marginBottom: 8, color: '#0f172a' },
  iaResultText: { color: '#0f172a', fontSize: 13, lineHeight: 20, marginBottom: 6 },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  iaTag: { borderRadius: 20, paddingVertical: 6, paddingHorizontal: 12, fontSize: 12, fontWeight: '700' },
  iaTagCat: { backgroundColor: '#eff6ff', color: '#0047AB' },
  iaTagUrg: { backgroundColor: '#fff7ed', color: '#ea580c' },
  iaTagVal: { backgroundColor: '#f0fdf4', color: '#16a34a' },
  infoBox: { backgroundColor: '#f0f7ff', borderRadius: 14, padding: 14, marginBottom: 14 },
  infoBoxText: { color: '#0047AB', fontSize: 13 },
  serviceDetailTitle: { fontSize: 18, fontWeight: '800', color: '#0f172a', marginBottom: 10 },
  serviceDetailDesc: { color: '#64748b', fontSize: 14, lineHeight: 20, marginBottom: 14 },
  techProfileHero: { backgroundColor: '#0047AB', borderRadius: 20, padding: 20, alignItems: 'center', marginBottom: 18 },
  techProfileAvatar: { width: 90, height: 90, borderRadius: 45, borderWidth: 3, borderColor: 'rgba(255,255,255,0.4)', marginBottom: 12 },
  techProfileName: { fontSize: 20, fontWeight: '800', color: '#fff', marginBottom: 4 },
  techProfileRole: { color: '#c7d9f5', fontSize: 13 },
  tecStatRow: { flexDirection: 'row', justifyContent: 'center', gap: 10, marginTop: 14 },
  tecStat: { backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8, alignItems: 'center' },
  tecStatVal: { fontSize: 16, fontWeight: '800', color: '#fff' },
  tecStatLbl: { fontSize: 10, color: '#a8c5f5', marginTop: 2 },
  skillRowWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  linkText: { color: '#0047AB' },
});