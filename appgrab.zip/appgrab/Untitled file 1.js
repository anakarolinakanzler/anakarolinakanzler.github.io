import React, { useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  StatusBar,
  Alert,
} from 'react-native';

export default function App() {
  const [titulo, setTitulo] = useState('');
  const [preco, setPreco] = useState('');
  const [cidade, setCidade] = useState('');

  const handleSubmit = () => {
    Alert.alert(
      'Imóvel cadastrado',
      `Título: ${titulo}\nPreço: ${preco}\nCidade: ${cidade}`
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#2c3e50" />

      <View style={styles.nav}>
        {['Início', 'Imóveis', 'Cadastrar', 'Contato'].map((item) => (
          <Text key={item} style={styles.navItem}>
            {item}
          </Text>
        ))}
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>Cadastro de Imóveis</Text>
        <Text style={styles.subtitle}>
          Cadastre seu imóvel de forma rápida e simples.
        </Text>

        <Image
          style={styles.image}
          source={{
            uri: 'https://images.pexels.com/photos/8470800/pexels-photo-8470800.jpeg',
          }}
        />

        <View style={styles.form}>
          <Text style={styles.label}>Título do imóvel</Text>
          <TextInput
            style={styles.input}
            placeholder="Ex: Casa com piscina"
            value={titulo}
            onChangeText={setTitulo}
          />

          <Text style={styles.label}>Preço</Text>
          <TextInput
            style={styles.input}
            placeholder="R$"
            value={preco}
            onChangeText={setPreco}
            keyboardType="numeric"
          />

          <Text style={styles.label}>Cidade</Text>
          <TextInput
            style={styles.input}
            placeholder="Cidade"
            value={cidade}
            onChangeText={setCidade}
          />

          <TouchableOpacity style={styles.button} onPress={handleSubmit}>
            <Text style={styles.buttonText}>Cadastrar Imóvel</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            © 2025 - ImobiWeb. Todos os direitos reservados.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  nav: {
    backgroundColor: '#2c3e50',
    flexDirection: 'row',
    justifyContent: 'center',
    flexWrap: 'wrap',
    paddingVertical: 16,
  },
  navItem: {
    color: '#fff',
    marginHorizontal: 10,
    fontWeight: '700',
    marginVertical: 4,
  },
  content: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#444',
    marginBottom: 16,
    textAlign: 'center',
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 12,
    marginBottom: 20,
  },
  form: {
    width: '100%',
    maxWidth: 500,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 6,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    marginBottom: 14,
  },
  button: {
    backgroundColor: '#2c3e50',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '700',
  },
  footer: {
    marginTop: 30,
    paddingVertical: 16,
    width: '100%',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
    borderRadius: 8,
  },
  footerText: {
    color: '#fff',
  },
});